# Documentazione Tecnica: BeeHunter Ultimate Edition

**Autore:** Manus AI
**Data:** 16 Marzo 2026
**Progetto:** BeeHunter Ultimate Edition v2.0 (Puglia Edition)

---

## 1. Panoramica del Progetto

**BeeHunter** è un'applicazione web mobile-first progettata per la gamification del turismo nella regione Puglia. L'obiettivo principale è incentivare l'esplorazione del territorio attraverso meccaniche di gioco (XP, livelli, badge, sfide giornaliere) e ricompense reali (coupon partner).

L'applicazione è stata sviluppata come una **Single-Page Application (SPA)** interamente contenuta in un unico file HTML, senza dipendenze da backend complessi, garantendo un'esecuzione rapida, portabilità e facilità di distribuzione.

## 2. Architettura Tecnica

L'architettura si basa su un approccio client-side puro, sfruttando le moderne API dei browser per la persistenza dei dati, la geolocalizzazione e l'accesso ai dispositivi multimediali.

### 2.1 Stack Tecnologico

| Componente | Tecnologia Utilizzata | Scopo |
|---|---|---|
| **Struttura & Logica** | HTML5, JavaScript (ES6+) | Struttura DOM, logica di stato, interazioni utente |
| **Stile & UI** | Tailwind CSS (via CDN), CSS Custom | Styling responsivo, design system, animazioni |
| **Mappe & Dati Spaziali** | Leaflet.js, MarkerCluster | Rendering mappa interattiva, raggruppamento punti |
| **Iconografia** | Font Awesome 6 | Icone vettoriali per UI e categorie |
| **Animazioni** | Animate.css, CSS Keyframes | Transizioni fluide, feedback visivi (toast, modali) |
| **Dati Esterni** | Open-Meteo API | Dati meteorologici in tempo reale (senza API key) |

### 2.2 Gestione dello Stato (State Management)

L'applicazione utilizza un oggetto JavaScript globale (`state`) per tracciare i progressi dell'utente. Questo stato viene costantemente sincronizzato con il `localStorage` del browser per garantire la persistenza dei dati tra le sessioni.

La struttura dello stato comprende:
- **Punteggio e Livello:** `xp` (punti esperienza accumulati).
- **Progressi:** `visited` (array di ID dei luoghi visitati), `completedTours` (tour completati), `badges` (badge sbloccati).
- **Economia:** `unlockedCoupons` (coupon riscattati).
- **Engagement:** `streak` (giorni consecutivi di accesso), `lastLogin` (timestamp ultimo accesso), `challengeProgress` (stato delle sfide giornaliere).
- **Preferenze:** `lang` (lingua corrente: 'it' o 'en').

### 2.3 Struttura del Database Locale

I dati dell'applicazione sono hardcoded in un oggetto `DB` costante, che funge da database read-only. Questo approccio elimina la necessità di chiamate di rete per il caricamento dei contenuti principali.

Il database è suddiviso in:
1. **Points:** 200 punti di interesse (15 reali + 185 generati proceduralmente per testare le performance del cluster). Ogni punto ha coordinate, categoria, XP reward e descrizioni multilingua.
2. **Tours:** Esperienze strutturate che raggruppano più punti e offrono ricompense maggiori.
3. **Coupons:** Ricompense reali riscattabili spendendo XP.
4. **Badges:** Obiettivi sbloccabili al raggiungimento di specifiche condizioni.
5. **Challenges:** Sfide dinamiche per incentivare l'uso quotidiano.

## 3. Flussi Funzionali Principali

### 3.1 Esplorazione e Validazione (Core Loop)

Il ciclo di gioco principale (Core Loop) si sviluppa attraverso i seguenti passaggi:
1. L'utente individua un punto di interesse sulla mappa (sezione **RADAR**).
2. Cliccando sul punto, si apre un modale di dettaglio.
3. L'utente avvia lo scanner AR (simulato tramite l'API `navigator.mediaDevices.getUserMedia`).
4. Dopo una validazione simulata, il sistema aggiorna lo stato:
   - Aggiunge l'ID del punto all'array `visited`.
   - Incrementa gli `xp`.
   - Registra l'azione nella `history`.
   - Verifica l'avanzamento delle sfide (`challengeProgress`).
   - Controlla lo sblocco di nuovi badge tramite la funzione `checkAchievements()`.
5. Lo stato viene salvato nel `localStorage` e l'interfaccia viene ri-renderizzata.

### 3.2 Sistema di Ricompense e Livelli

L'applicazione implementa un sistema di progressione basato su soglie di XP predefinite:
- *Larva Barese* (0 XP) → *Esploratore* (300 XP) → *Hunter* (800 XP) → *Pro Hunter* (1800 XP) → *Master Hunter* (3500 XP) → *Ultimate Legend* (6000 XP).

Gli XP accumulati fungono anche da valuta virtuale. Nella sezione **SHOP**, l'utente può "spendere" XP per sbloccare coupon. Questa operazione riduce il saldo XP ma non influisce sul livello raggiunto (che si basa sugli XP totali storici, sebbene nell'implementazione attuale si utilizzi il saldo corrente per semplicità dimostrativa).

### 3.3 Internazionalizzazione (i18n)

Il supporto multilingua è gestito tramite un dizionario `I18N` e proprietà bilingue (`it`, `en`) all'interno degli oggetti del database. La funzione `applyTranslations()` scansiona il DOM alla ricerca di classi specifiche (es. `.t-radar`) e sostituisce il testo in base alla lingua selezionata nello stato.

## 4. Miglioramenti e Nuove Funzionalità Implementate

Rispetto al codice originale fornito, sono stati apportati i seguenti interventi architetturali e funzionali:

1. **Risoluzione Bug Strutturali:**
   - Correzione di errori di sintassi JSON nel database originale.
   - Unificazione dei database frammentati (`basePoints` e `DB.points`) in un'unica struttura coerente.
   - Sostituzione dei placeholder immagine con URL reali da Unsplash.

2. **Nuove Funzionalità Aggiunte:**
   - **Integrazione Meteo:** Chiamata asincrona all'API Open-Meteo per mostrare le condizioni atmosferiche di Bari in tempo reale.
   - **Sfide Giornaliere (Challenges):** Nuovo sistema di missioni (es. "Visita 2 luoghi Food") con tracciamento progressi.
   - **Sistema di Streak:** Tracciamento degli accessi consecutivi giornalieri con bonus XP.
   - **Filtri Avanzati e Ricerca:** Implementazione di una barra di ricerca testuale e chip di filtro per categoria sulla mappa.
   - **Modalità Offline:** Rilevamento dello stato di rete (`navigator.onLine`) con banner di avviso.
   - **Esportazione Dati:** Funzionalità per scaricare i propri progressi in formato JSON.

3. **Ottimizzazione UI/UX:**
   - Ridisegno completo dell'interfaccia con Tailwind CSS, migliorando la leggibilità e l'estetica mobile.
   - Implementazione di un Side Menu a comparsa per le impostazioni secondarie.
   - Aggiunta di animazioni fluide per modali, toast e transizioni di pagina.

## 5. Considerazioni per Sviluppi Futuri

Per trasformare questo prototipo in un'applicazione di produzione, si raccomandano i seguenti step architetturali:

1. **Migrazione a Framework Reattivo:** Passaggio da Vanilla JS a React o Vue.js per una migliore gestione del DOM e dello stato.
2. **Integrazione Backend:** Sostituzione del `localStorage` con un database remoto (es. Firebase, Supabase) per sincronizzazione cross-device e autenticazione utente.
3. **Validazione Geospaziale Reale:** Implementazione dell'API `navigator.geolocation` per consentire la validazione dei punti solo se l'utente si trova fisicamente entro un raggio specifico (es. 50 metri) dalle coordinate del luogo.
4. **PWA (Progressive Web App):** Aggiunta di un Service Worker e di un file `manifest.json` per consentire l'installazione dell'app sulla home screen e il funzionamento offline completo.
